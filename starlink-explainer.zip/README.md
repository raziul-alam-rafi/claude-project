# Starlink explainer — Remotion project

    npm install
    npx remotion studio                      # preview (composition: Main)
    npx remotion render src/index.ts Main out/video.mp4

- Timing comes only from `public/rafi.srt` → `src/cues.ts` (regenerate: `node scripts/srt-to-cues.mjs`).
- Optional: put the voiceover at `public/voiceover.mp3` — plays in Studio only (`src/config.ts`).
- SFX live in `public/sfx/` (regenerate: `python3 scripts/make-sfx.py`).
- Colors / fonts / easings: `src/theme.ts`.
