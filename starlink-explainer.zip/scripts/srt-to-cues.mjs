// SRT -> src/cues.ts  (run: node scripts/srt-to-cues.mjs [path/to/file.srt])
import fs from "node:fs";
const src = process.argv[2] ?? "public/rafi.srt";
const raw = fs.readFileSync(src, "utf8").replace(/\r/g, "").trim();
const ts = (s) => { const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/); return +m[1]*3600 + +m[2]*60 + +m[3] + +m[4]/1000; };
const cues = raw.split(/\n\s*\n/).map((blk) => {
  const l = blk.split("\n").map((x) => x.trim()).filter(Boolean);
  const [a, b] = l[1].split("-->");
  return { start: ts(a), end: ts(b), text: l.slice(2).join(" ").replace(/\s+/g, " ").trim() };
});
fs.writeFileSync("src/cues.ts",
`// AUTO-GENERATED from ${src} by scripts/srt-to-cues.mjs — do not edit by hand.
export type Cue = { start: number; end: number; text: string };
export const cues: Cue[] = ${JSON.stringify(cues, null, 2)};
`);
console.log(cues.length, "cues, ends at", cues.at(-1).end);
