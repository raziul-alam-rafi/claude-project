# Synthesises the small SFX kit into public/sfx/*.wav (16-bit, mono, 44.1 kHz). Deterministic.
import numpy as np, wave, os
SR = 44100
rng = np.random.default_rng(7)
out = os.path.join(os.path.dirname(__file__), "..", "public", "sfx")
os.makedirs(out, exist_ok=True)

def t(d): return np.arange(int(SR * d)) / SR
def lowpass(x, fc):
    a = np.exp(-2 * np.pi * fc / SR); y = np.zeros_like(x); s = 0.0
    for i, v in enumerate(x): s = (1 - a) * v + a * s; y[i] = s
    return y
def highpass(x, fc): return x - lowpass(x, fc)
def bandpass_sweep(x, f0, f1, q=2.5):
    n = len(x); fs = np.exp(np.linspace(np.log(f0), np.log(f1), n)); y = np.zeros(n); lo = bp = 0.0
    for i in range(n):
        f = 2 * np.sin(np.pi * fs[i] / SR); hp = x[i] - lo - bp / q
        bp += f * hp; lo += f * bp; y[i] = bp
    return y
def reverb(x, tail=0.06):
    y = np.concatenate([x, np.zeros(int(SR * tail))])
    for d, g in ((0.011, 0.16), (0.019, 0.11), (0.031, 0.07)):
        k = int(SR * d); y[k:k + len(x)] += x * g
    return y
def env(n, att, dec, curve=4.0):
    e = np.ones(n); a = max(1, int(SR * att)); e[:a] = np.linspace(0, 1, a) ** 1.5
    e *= np.exp(-curve * np.arange(n) / (SR * dec)); return e
def fade_out(x, ms=12):
    k = int(SR * ms / 1000); x[-k:] *= np.linspace(1, 0, k); return x
def finish(x, peak=0.7, rms_db=-22.0):
    """Fade tail, then match loudness (RMS target) while keeping peak <= 0.8 so nothing clips."""
    x = fade_out(x.copy()); x = x / (np.max(np.abs(x)) + 1e-9)
    r = np.sqrt(np.mean(x ** 2)); x = x * min(10 ** (rms_db / 20) / r, 0.8 / np.max(np.abs(x)))
    return x
def save(name, x):
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2")
    with wave.open(os.path.join(out, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())

# pop — sine with fast downward pitch + short envelope
d = 0.20; tt = t(d); f = 180 + 420 * np.exp(-tt * 28); ph = 2 * np.pi * np.cumsum(f) / SR
x = np.sin(ph) * env(len(tt), 0.003, 0.07, 5); save("pop", finish(reverb(lowpass(x, 3200))))

# click — high-passed noise burst + tiny tick
d = 0.09; tt = t(d); n = highpass(rng.standard_normal(len(tt)), 2500) * env(len(tt), 0.0008, 0.012, 5)
tick = np.sin(2 * np.pi * 1900 * tt) * env(len(tt), 0.0005, 0.009, 5) * 0.4
save("click", finish(lowpass(n + tick, 9000)))

# whoosh — soft band-pass noise sweep (title / statement entries)
d = 0.62; tt = t(d); n = rng.standard_normal(len(tt)); sw = bandpass_sweep(n, 350, 2300)
w = np.sin(np.pi * np.clip(tt / d, 0, 1)) ** 2; save("whoosh", finish(reverb(lowpass(sw * w, 5000))))

# swipe — shorter, brighter whoosh (scene transitions)
d = 0.42; tt = t(d); n = rng.standard_normal(len(tt)); sw = bandpass_sweep(n, 600, 3800, 2.2)
w = np.sin(np.pi * np.clip(tt / d, 0, 1)) ** 1.6; save("swipe", finish(reverb(lowpass(sw * w, 6500), 0.05)))

# chime — soft plucked partials with gentle overtones (logo / satellite reveals)
d = 0.40; tt = t(d); x = np.zeros(len(tt))
for fr, g, dc in ((880, 1.0, 0.22), (1318.5, 0.45, 0.16), (2093, 0.18, 0.10)):
    x += g * np.sin(2 * np.pi * fr * tt) * env(len(tt), 0.004, dc, 4.5)
save("chime", finish(reverb(lowpass(x, 4200), 0.09)))

# thud — very soft low thump (hook / key message, restrained)
d = 0.32; tt = t(d); f = 46 + 70 * np.exp(-tt * 22); ph = 2 * np.pi * np.cumsum(f) / SR
x = np.sin(ph) * env(len(tt), 0.006, 0.11, 4.5); save("thud", finish(lowpass(x, 900)))
print("sfx written to", os.path.abspath(out))
