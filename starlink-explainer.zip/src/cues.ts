// AUTO-GENERATED from public/rafi.srt by scripts/srt-to-cues.mjs — do not edit by hand.
export type Cue = { start: number; end: number; text: string };
export const cues: Cue[] = [
  {
    "start": 0.32,
    "end": 6.12,
    "text": "Starlink এর কাজ হলো পৃথিবীর সেই Internet Network অর্থাৎ Facebook বা YouTube এর"
  },
  {
    "start": 6.12,
    "end": 13,
    "text": "Server এর সঙ্গে আপনাকে এমনভাবে যুক্ত করা। আর এর জন্য পৃথিবীর নিচু কক্ষপথে হাজার"
  },
  {
    "start": 13,
    "end": 18.5,
    "text": "হাজার Satellite ঘুরছে। এগুলো পৃথিবী থেকে প্রায় ৫৫০ কিলোমিটার উপরে"
  },
  {
    "start": 18.5,
    "end": 25.26,
    "text": "অবস্থান করে। আর এই Satelliteগুলোর গতি এত বেশি যে প্রতি ৯৫ মিনিট পর পর"
  },
  {
    "start": 25.26,
    "end": 31.68,
    "text": "এগুলো পৃথিবীকে একবার করে প্রদক্ষিণ করে। কিন্তু এত দ্রুতগতিতে চলা Satelliteএর সঙ্গে"
  },
  {
    "start": 31.68,
    "end": 38.18,
    "text": "আপনার Device সংযোগ ধরে রাখে কিভাবে? এর উত্তর লুকিয়ে আছে ছোট্ট একটা Dishএর ভিতরে।"
  },
  {
    "start": 38.18,
    "end": 43.8,
    "text": "আচ্ছা, প্রথমে আপনাকে বুঝতে হবে সাধারণ বাসাবাড়িতে একটা ছোট্ট Dish Antenna এর"
  },
  {
    "start": 43.8,
    "end": 49.24,
    "text": "মাধ্যমে Starlink কিভাবে Internet সেবা দিয়ে থাকে। আর এটি বুঝে গেলে আপনি খুব"
  },
  {
    "start": 49.24,
    "end": 54.14,
    "text": "সহজেই বুঝতে পারবেন কোন Antenna ছাড়া সরাসরি Mobile এ কিভাবে Starlink চলে।"
  }
];
