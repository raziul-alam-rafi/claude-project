// Preview voiceover: public/voiceover.mp3 (optional). Plays in Studio only by default.
export const ENABLE_PREVIEW_VOICEOVER = true; // master switch
export const VOICEOVER_IN_RENDER = false;     // keep false: final MP4 gets SFX only
