// theme.ts — single source of truth: colors, fonts, easings, springs, sizes.
import { Easing } from "remotion";
import { fontFamily } from "./font";

export const theme = {
  colors: {
    // Scheme 1 — Deep Space
    bg: "#070B1A",
    bgAlt: "#0E1530",
    primary: "#3D7BFF", // hero
    accent: "#22D3EE",
    text: "#F1F5FF",
    textDim: "#9FB0D6",
    ink: "#04060F",
    glow: "rgba(61, 123, 255, 0.42)",
    surface: "rgba(241, 245, 255, 0.06)",
    surfaceStrong: "rgba(241, 245, 255, 0.10)",
    border: "rgba(241, 245, 255, 0.16)",
    line: "rgba(159, 176, 214, 0.40)",
    shade: "rgba(0, 0, 0, 0.22)",
  },
  fonts: {
    display: `${fontFamily}, "Noto Sans Bengali", "Segoe UI", sans-serif`,
    body: `${fontFamily}, "Noto Sans Bengali", "Segoe UI", sans-serif`,
  },
  weight: { display: 700, strong: 600, body: 500 },
  radius: { card: 36, tile: 30, pill: 999 },
  shadow: {
    card: "0 40px 80px -24px rgba(0,0,0,0.65), inset 0 1px 0 rgba(241,245,255,0.18)",
    glow: "0 0 60px rgba(61,123,255,0.40), 0 0 140px rgba(61,123,255,0.20)",
  },
  size: { hero: 188, title: 104, sub: 72, label: 44, small: 36 },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;
