import React from "react";
import { useCurrentFrame } from "remotion";
import { theme } from "../theme";

/** Rotating dot-matrix globe (pure SVG, theme colors). */
export const DotGlobe: React.FC<{ size: number; speed?: number; tilt?: number }> = ({ size, speed = 0.012, tilt = 0.38 }) => {
  const frame = useCurrentFrame();
  const R = size / 2;
  const rot = frame * speed;
  const dots: React.ReactNode[] = [];
  let k = 0;
  for (let lat = -84; lat <= 84; lat += 7) {
    const phi = (lat * Math.PI) / 180;
    const n = Math.max(1, Math.round(54 * Math.cos(phi)));
    for (let i = 0; i < n; i++) {
      const lon0 = (i / n) * Math.PI * 2;
      const lon = lon0 + rot;
      const x3 = Math.cos(phi) * Math.sin(lon);
      const y3 = Math.sin(phi);
      const z3 = Math.cos(phi) * Math.cos(lon);
      const y2 = y3 * Math.cos(tilt) - z3 * Math.sin(tilt);
      const z2 = y3 * Math.sin(tilt) + z3 * Math.cos(tilt);
      if (z2 < 0.02) continue;
      const land = Math.sin(phi * 2.2 + 1.3) * Math.sin(lon0 * 1.6 + 0.4) + 0.6 * Math.sin(lon0 * 3.1 - phi * 1.7) > 0.12;
      dots.push(
        <circle key={k++} cx={R + x3 * R * 0.98} cy={R - y2 * R * 0.98} r={size * 0.0072 * (0.45 + z2)}
          fill={land ? theme.colors.accent : theme.colors.textDim} opacity={(land ? 0.95 : 0.28) * (0.35 + 0.65 * z2)} />
      );
    }
  }
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ overflow: "visible" }}>
      <defs>
        <radialGradient id="gl-body" cx="38%" cy="32%" r="75%">
          <stop offset="0%" stopColor={theme.colors.bgAlt} />
          <stop offset="100%" stopColor={theme.colors.bg} />
        </radialGradient>
        <radialGradient id="gl-atmo" cx="50%" cy="50%" r="50%">
          <stop offset="88%" stopColor={theme.colors.primary} stopOpacity="0" />
          <stop offset="96%" stopColor={theme.colors.primary} stopOpacity="0.55" />
          <stop offset="100%" stopColor={theme.colors.primary} stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx={R} cy={R} r={R * 1.12} fill="url(#gl-atmo)" />
      <circle cx={R} cy={R} r={R} fill="url(#gl-body)" stroke={theme.colors.border} strokeWidth={2} />
      {dots}
    </svg>
  );
};
