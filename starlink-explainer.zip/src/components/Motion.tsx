import React, { CSSProperties, ReactNode } from "react";
import { Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export const clampX = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
export const toBn = (n: number) => String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);

export const gradientText: CSSProperties = {
  background: `linear-gradient(100deg, ${theme.colors.primary}, ${theme.colors.accent})`,
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
  WebkitTextFillColor: "transparent",
};

/** Entrance: opacity + rise + scale, spring-driven. */
export const Entrance: React.FC<{
  delay?: number; y?: number; x?: number; from?: number;
  preset?: keyof typeof theme.spring; style?: CSSProperties; children: ReactNode;
}> = ({ delay = 0, y = 40, x = 0, from = 0.94, preset = "smooth", style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring[preset] });
  const o = interpolate(p, [0, 0.35], [0, 1], clampX);
  return (
    <div style={{ opacity: o, willChange: "transform, opacity",
      transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${interpolate(p, [0, 1], [from, 1])})`, ...style }}>
      {children}
    </div>
  );
};

/** Word-by-word staggered reveal. Splits on SPACES only (Bengali conjuncts stay intact). */
export const WordReveal: React.FC<{
  text: string; size: number; delay?: number; per?: number; hl?: string[];
  weight?: number; justify?: "flex-start" | "center" | "flex-end"; color?: string; style?: CSSProperties;
}> = ({ text, size, delay = 0, per = 4, hl = [], weight = theme.weight.display, justify = "flex-start", color = theme.colors.text, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{ display: "flex", flexWrap: "wrap", columnGap: Math.round(size * 0.27), rowGap: 0, justifyContent: justify,
      fontFamily: theme.fonts.display, fontWeight: weight, fontSize: size, lineHeight: 1.38, letterSpacing: 0, color, ...style }}>
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const isHl = hl.includes(w);
        return (
          <span key={i} style={{ display: "inline-block", opacity: interpolate(p, [0, 0.4], [0, 1], clampX),
            transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
            paddingBottom: 6, ...(isHl ? gradientText : {}) }}>{w}</span>
        );
      })}
    </div>
  );
};

/** Rolling counter that renders Bengali digits (script numbers only). */
export const BnCounter: React.FC<{ to: number; delay: number; size: number; style?: CSSProperties }> = ({ to, delay, size, style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: { damping: 26, stiffness: 95, mass: 0.9 } });
  const v = Math.min(to, Math.max(0, Math.round(interpolate(p, [0, 1], [0, to]))));
  return <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: size, lineHeight: 1.3, ...style }}>{toBn(v)}</span>;
};

/** Slow breathing micro-motion for idle elements. */
export const Breathe: React.FC<{ amp?: number; speed?: number; phase?: number; style?: CSSProperties; children: ReactNode }> = ({ amp = 6, speed = 30, phase = 0, style, children }) => {
  const frame = useCurrentFrame();
  return <div style={{ transform: `translateY(${Math.sin(frame / speed + phase) * amp}px) scale(${1 + Math.sin(frame / (speed * 0.8) + phase) * 0.012})`, ...style }}>{children}</div>;
};

/** Still image with Ken Burns drift. */
export const KenImg: React.FC<{ src: string; style?: CSSProperties; zoom?: number; dir?: 1 | -1 }> = ({ src, style, zoom = 1.08, dir = 1 }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t = interpolate(frame, [0, durationInFrames], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const s = dir > 0 ? 1 + (zoom - 1) * t : zoom - (zoom - 1) * t;
  return <Img src={staticFile(src)} style={{ display: "block", width: "100%", height: "100%", objectFit: "contain",
    transform: `scale(${s}) translateX(${(dir > 0 ? -1 : 1) * t * 10}px)`, ...style }} />;
};

/** Exit style for the last `n` frames of a scene (faster than entrances). */
export const useExit = (n = 10): CSSProperties => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const a = durationInFrames - n - 2;
  const o = interpolate(frame, [a, a + n], [1, 0], { easing: theme.ease.in, ...clampX });
  const y = interpolate(frame, [a, a + n], [0, -36], { easing: theme.ease.in, ...clampX });
  return { opacity: o, transform: `translateY(${y}px)` };
};

/** Draws a line (x1,y1)->(x2,y2) with animated dashes + optional travelling packets. */
export const Link: React.FC<{
  x1: number; y1: number; x2: number; y2: number; delay: number; packets?: number; color?: string; width?: number; fade?: number;
}> = ({ x1, y1, x2, y2, delay, packets = 0, color = theme.colors.accent, width = 7, fade = 1 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  const len = Math.hypot(x2 - x1, y2 - y1);
  return (
    <g opacity={fade}>
      <line x1={x1} y1={y1} x2={x1 + (x2 - x1) * p} y2={y1 + (y2 - y1) * p} stroke={color} strokeWidth={width}
        strokeLinecap="round" strokeDasharray="1 17" strokeDashoffset={-frame * 1.2} opacity={0.95} />
      {Array.from({ length: packets }).map((_, i) => {
        const u = ((frame - delay - 14) / 46 + i / packets) % 1;
        const vis = p > 0.98 && frame > delay + 14 ? 1 : 0;
        return <circle key={i} cx={x1 + (x2 - x1) * u} cy={y1 + (y2 - y1) * u} r={width * 1.5} fill={theme.colors.text} opacity={vis * Math.sin(u * Math.PI)} />;
      })}
    </g>
  );
};
