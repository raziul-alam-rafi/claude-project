import React, { ReactNode } from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { BgMesh } from "./Backdrop";
import { clampX, useExit } from "./Motion";

/** Scene shell: own background, diagonal mask-wipe in, content exit. */
export const SceneShell: React.FC<{ seed: number; first?: boolean; last?: boolean; children: ReactNode }> = ({ seed, first, last, children }) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const exit = useExit(last ? 12 : 9);
  const w = interpolate(frame, [0, 14], [-12, 118], { easing: theme.ease.out, ...clampX });
  const clip = first ? undefined : `polygon(0% 0%, ${w + 12}% 0%, ${w - 12}% 100%, 0% 100%)`;
  const lastFade = last ? interpolate(frame, [durationInFrames - 12, durationInFrames - 1], [1, 0], { easing: theme.ease.in, ...clampX }) : 1;
  return (
    <AbsoluteFill style={{ clipPath: clip, opacity: lastFade }}>
      <BgMesh seed={seed} />
      <AbsoluteFill style={exit}>{children}</AbsoluteFill>
    </AbsoluteFill>
  );
};
