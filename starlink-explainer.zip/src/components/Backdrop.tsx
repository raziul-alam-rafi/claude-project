import React from "react";
import { AbsoluteFill, random, useCurrentFrame } from "remotion";
import { theme } from "../theme";

/** Layer 1: animated background mesh + sparse star field (never a flat fill). */
export const BgMesh: React.FC<{ seed?: number }> = ({ seed = 0 }) => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55 + seed) * 50;
  const d2 = Math.cos(frame / 70 + seed) * 40;
  const flip = seed % 2 === 0 ? 1 : -1;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%",
        top: -520, left: flip > 0 ? -380 + d1 : 1000 + d1, filter: "blur(50px)",
        background: `radial-gradient(circle, ${theme.colors.primary}38, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%",
        bottom: -460, right: flip > 0 ? -300 - d2 : 1000 - d2, filter: "blur(70px)",
        background: `radial-gradient(circle, ${theme.colors.accent}26, transparent 65%)` }} />
      <div style={{ position: "absolute", inset: 0,
        background: `radial-gradient(ellipse at 50% 120%, ${theme.colors.bgAlt}, transparent 60%)` }} />
      {Array.from({ length: 70 }).map((_, i) => {
        const x = random(`sx${seed}-${i}`) * 1920;
        const y = random(`sy${seed}-${i}`) * 1080;
        const s = 1.5 + random(`ss${seed}-${i}`) * 2.5;
        const tw = 0.35 + 0.65 * Math.abs(Math.sin(frame / (30 + random(`st${i}`) * 40) + i));
        return <div key={i} style={{ position: "absolute", left: x, top: y - frame * 0.05 * s, width: s, height: s,
          borderRadius: "50%", background: theme.colors.text, opacity: tw * 0.55 }} />;
      })}
    </AbsoluteFill>
  );
};

/** Layer 4: unifying grade. */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.12 }} />
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${theme.colors.shade}, transparent 14%, transparent 86%, ${theme.colors.shade})` }} />
  </AbsoluteFill>
);

/** Layer 5a: procedural grain. */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
    backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />;
};

/** Layer 5b: vignette (topmost). */
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none",
    background: `radial-gradient(ellipse at center, transparent 56%, ${theme.colors.shade} 100%)` }} />
);

export const Finish: React.FC = () => (
  <>
    <Grade />
    <Grain />
    <Vignette />
  </>
);
