import React, { CSSProperties, ReactNode } from "react";
import { Img, staticFile } from "remotion";
import { theme } from "../theme";

export const Glass: React.FC<{ style?: CSSProperties; children?: ReactNode; radius?: number }> = ({ style, children, radius = theme.radius.card }) => (
  <div style={{ position: "relative", boxSizing: "border-box", borderRadius: radius, background: `linear-gradient(145deg, ${theme.colors.surfaceStrong}, ${theme.colors.surface})`,
    border: `1px solid ${theme.colors.border}`, boxShadow: theme.shadow.card, backdropFilter: "blur(14px)", ...style }}>
    {children}
  </div>
);

/** Logo in a glass tile. Logo files are used untouched (only cropped by the tile's own rounded mask). */
export const LogoTile: React.FC<{ logo: "youtube" | "facebook"; size: number; style?: CSSProperties }> = ({ logo, size, style }) => {
  const pad = Math.round(size * 0.17);
  const inner = size - pad * 2;
  return (
    <Glass radius={Math.round(size * 0.24)} style={{ width: size, height: size, display: "flex", alignItems: "center", justifyContent: "center", ...style }}>
      {logo === "facebook" ? (
        <div style={{ width: inner, height: inner, borderRadius: "22%", overflow: "hidden" }}>
          <Img src={staticFile("assets/facebook.png")} style={{ width: "100%", height: "100%", display: "block", transform: "scale(1.035)" }} />
        </div>
      ) : (
        <Img src={staticFile("assets/youtube.png")} style={{ width: inner, height: "auto", display: "block" }} />
      )}
    </Glass>
  );
};

export const Chip: React.FC<{ children: ReactNode; size?: number; style?: CSSProperties }> = ({ children, size = theme.size.small, style }) => (
  <div style={{ display: "inline-flex", alignItems: "center", padding: `${Math.round(size * 0.18)}px ${Math.round(size * 0.6)}px`,
    borderRadius: theme.radius.pill, background: theme.colors.surfaceStrong, border: `1px solid ${theme.colors.border}`,
    fontFamily: theme.fonts.body, fontWeight: theme.weight.strong, fontSize: size, lineHeight: 1.5, color: theme.colors.text, ...style }}>
    {children}
  </div>
);
