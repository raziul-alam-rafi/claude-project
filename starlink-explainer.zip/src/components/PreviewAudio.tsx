import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { ENABLE_PREVIEW_VOICEOVER, VOICEOVER_IN_RENDER } from "../config";

/** Plays public/voiceover.mp3 for sync checks if the file exists; silently skipped otherwise. */
export const PreviewAudio: React.FC = () => {
  const { isRendering } = getRemotionEnvironment();
  const enabled = ENABLE_PREVIEW_VOICEOVER && (!isRendering || VOICEOVER_IN_RENDER);
  const [exists, setExists] = useState(false);
  const [handle] = useState(() => (enabled ? delayRender("check voiceover.mp3") : null));
  useEffect(() => {
    if (!enabled) return;
    let alive = true;
    fetch(staticFile("voiceover.mp3"), { method: "HEAD" })
      .then((r) => { if (alive) setExists(r.ok && !/text\/html/.test(r.headers.get("content-type") ?? "")); })
      .catch(() => undefined)
      .finally(() => { if (handle !== null) continueRender(handle); });
    return () => { alive = false; };
  }, [enabled, handle]);
  if (!enabled || !exists) return null;
  return <Audio src={staticFile("voiceover.mp3")} volume={1} />;
};
