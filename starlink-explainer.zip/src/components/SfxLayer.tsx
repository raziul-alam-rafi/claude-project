import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { sfxEvents } from "../sfx";

export const SfxLayer: React.FC = () => (
  <>
    {sfxEvents.map((e, i) => (
      <Sequence key={i} from={e.frame} durationInFrames={40} layout="none">
        <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.volume} playbackRate={e.rate ?? 1} />
      </Sequence>
    ))}
  </>
);
