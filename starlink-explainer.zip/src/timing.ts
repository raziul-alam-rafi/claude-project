// All timing is derived from the SRT (src/cues.ts). Nothing is hand-placed.
import { cues } from "./cues";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const LEAD = 5; // visuals land 4–6 frames before the spoken word

const f = (s: number) => Math.round(s * FPS);
export const cueStart = (n: number) => f(cues[n - 1].start);
export const cueEnd = (n: number) => f(cues[n - 1].end);
export const TOTAL = Math.ceil(cues[cues.length - 1].end * FPS);

/** Estimated frame of a keyword inside cue n (proportional position in the cue text), minus LEAD. */
export const kw = (n: number, word: string, nth = 0): number => {
  const c = cues[n - 1];
  let idx = -1;
  for (let i = 0; i <= nth; i++) idx = c.text.indexOf(word, idx + 1);
  if (idx < 0) throw new Error(`keyword "${word}" not found in cue ${n}`);
  const frac = idx / c.text.length;
  return Math.round(c.start * FPS + frac * (c.end - c.start) * FPS) - LEAD;
};

export type SceneKey = "hook" | "link" | "orbit" | "speed" | "reveal" | "flow" | "mobile";
export const SCENE_ORDER: SceneKey[] = ["hook", "link", "orbit", "speed", "reveal", "flow", "mobile"];

// scene boundaries = cue boundaries
export const SC: Record<SceneKey, { from: number; to: number }> = {
  hook:   { from: 0,           to: cueStart(2) },
  link:   { from: cueStart(2), to: cueStart(3) },
  orbit:  { from: cueStart(3), to: cueStart(5) },
  speed:  { from: cueStart(5), to: cueStart(6) },
  reveal: { from: cueStart(6), to: cueStart(7) },
  flow:   { from: cueStart(7), to: cueStart(9) },
  mobile: { from: cueStart(9), to: TOTAL },
};

export const PRE = 6;   // incoming scene starts early (its wipe lands on the boundary)
export const POST = 10; // outgoing scene stays under the wipe
export const seqFrom = (k: SceneKey) => (k === "hook" ? 0 : SC[k].from - PRE);
export const seqDur = (k: SceneKey) => (k === "mobile" ? TOTAL : SC[k].to + POST) - seqFrom(k);
/** global frame -> frame local to scene k */
export const loc = (k: SceneKey, g: number) => g - seqFrom(k);

// Named moments (global frames), all from the SRT.
export const T = {
  hook:   { title: 3, yt: kw(1, "YouTube"), fb: kw(1, "Facebook") },
  link:   { server: cueStart(2) - LEAD, you: kw(2, "আপনাকে"), join: kw(2, "যুক্ত"), low: kw(2, "নিচু"), sat: kw(2, "কক্ষপথে") },
  orbit:  { head: cueStart(3) - LEAD, km: kw(3, "৫৫০"), speed: kw(4, "গতি"), min: kw(4, "৯৫") },
  speed:  { loop: cueStart(5) - LEAD, fast: kw(5, "দ্রুতগতিতে"), device: kw(5, "Satelliteএর") },
  reveal: { q: cueStart(6) - LEAD, dev: kw(6, "Device"), ans: kw(6, "উত্তর"), dish: kw(6, "Dish") },
  flow:   { house: kw(7, "বাসাবাড়িতে"), dish: kw(7, "Dish"), star: kw(8, "Starlink"), net: kw(8, "Internet") },
  mobile: { noAnt: kw(9, "Antenna"), direct: kw(9, "সরাসরি"), mob: kw(9, "Mobile"), star: kw(9, "Starlink") },
};
