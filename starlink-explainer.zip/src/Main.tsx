import React from "react";
import { AbsoluteFill, Sequence } from "remotion";
import { Finish } from "./components/Backdrop";
import { PreviewAudio } from "./components/PreviewAudio";
import { SfxLayer } from "./components/SfxLayer";
import { Hook } from "./scenes/Hook";
import { LinkScene } from "./scenes/Link";
import { Orbit } from "./scenes/Orbit";
import { Speed } from "./scenes/Speed";
import { Reveal } from "./scenes/Reveal";
import { Flow } from "./scenes/Flow";
import { Mobile } from "./scenes/Mobile";
import { SCENE_ORDER, SceneKey, seqDur, seqFrom } from "./timing";
import { theme } from "./theme";

const scenes: Record<SceneKey, React.FC> = { hook: Hook, link: LinkScene, orbit: Orbit, speed: Speed, reveal: Reveal, flow: Flow, mobile: Mobile };

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg }}>
    {SCENE_ORDER.map((k) => {
      const C = scenes[k];
      return (
        <Sequence key={k} from={seqFrom(k)} durationInFrames={seqDur(k)} name={k}>
          <C />
        </Sequence>
      );
    })}
    <Finish />
    <SfxLayer />
    <PreviewAudio />
  </AbsoluteFill>
);
