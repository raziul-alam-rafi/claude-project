import React from "react";
import { interpolate, random, useCurrentFrame, useVideoConfig } from "remotion";
import { Breathe, Entrance, KenImg, WordReveal, clampX, gradientText } from "../components/Motion";
import { Chip } from "../components/Glass";
import { DotGlobe } from "../components/Globe";
import { SceneShell } from "../components/Shell";
import { Phone } from "./Link";
import { theme } from "../theme";
import { T, loc } from "../timing";

export const Speed: React.FC = () => {
  const frame = useCurrentFrame();
  const L = (g: number) => loc("speed", g);
  const s0 = L(T.speed.fast);
  const loopIn = interpolate(frame, [L(T.speed.loop), L(T.speed.loop) + 16], [0, 1], { easing: theme.ease.out, ...clampX });
  const loopOut = interpolate(frame, [s0 - 14, s0 - 4], [1, 0], { easing: theme.ease.in, ...clampX });
  const loopA = loopIn * loopOut;
  const lp = interpolate(frame, [L(T.speed.loop) + 8, s0 - 6], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const speedLines = Array.from({ length: 16 }).map((_, i) => {
    const len = 260 + random(`l${i}`) * 520;
    const y = 80 + random(`y${i}`) * 920;
    const v = 38 + random(`v${i}`) * 44;
    const x = 2100 - ((frame * v + random(`o${i}`) * 2600) % (2100 + len + 200)) ;
    return { len, y, x, i };
  });
  const sp = Math.max(0, frame - s0);
  const cyc = sp % 64;
  const sx = interpolate(cyc, [0, 40], [2050, -330], { easing: theme.ease.inOut, ...clampX });
  const sy = 215 + Math.sin(sp / 64 * Math.PI * 2) * 10;
  const satVis = frame >= s0 - 2 ? 1 : 0;
  const flick = Math.abs(Math.sin(frame / 3.2)) > 0.35 ? 1 : 0.15;
  const linkA = interpolate(frame, [L(T.speed.device), L(T.speed.device) + 8], [0, 1], clampX);
  return (
    <SceneShell seed={4}>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0, opacity: interpolate(frame, [s0 - 6, s0 + 10], [0, 1], clampX) }}>
        {speedLines.map((l) => (
          <line key={l.i} x1={l.x} y1={l.y} x2={l.x + l.len} y2={l.y} stroke={theme.colors.text} strokeWidth={2.5} strokeLinecap="round" opacity={0.10 + 0.12 * random(`q${l.i}`)} />
        ))}
        <line x1={sx + 85} y1={sy + 95} x2={1665} y2={560} stroke={theme.colors.accent} strokeWidth={4} strokeDasharray="2 14" strokeLinecap="round" opacity={linkA * flick * satVis} />
      </svg>

      <div style={{ position: "absolute", left: 0, top: 0, width: 1920, height: 1080, opacity: loopA, transform: `scale(${0.9 + 0.1 * loopIn})` }}>
        <div style={{ position: "absolute", left: 960 - 190, top: 500 - 190 }}><DotGlobe size={380} speed={0.016} /></div>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          <circle cx={960} cy={500} r={300} fill="none" stroke={theme.colors.line} strokeWidth={3} strokeDasharray="3 12" />
          <path d={`M ${960} ${200} A 300 300 0 ${lp > 0.5 ? 1 : 0} 1 ${960 + Math.sin(lp * Math.PI * 2) * 300} ${500 - Math.cos(lp * Math.PI * 2) * 300}`} fill="none" stroke={theme.colors.accent} strokeWidth={7} strokeLinecap="round" opacity={lp > 0.01 ? 0.9 : 0} />
        </svg>
        <div style={{ position: "absolute", left: 960 + Math.sin(lp * Math.PI * 2) * 300 - 70, top: 500 - Math.cos(lp * Math.PI * 2) * 300 - 70, width: 140, height: 140 }}>
          <KenImg src="assets/satellite.png" zoom={1.04} />
        </div>
        <div style={{ position: "absolute", left: 960 - 200, top: 880, width: 400, display: "flex", justifyContent: "center" }}>
          <Chip size={52}>পৃথিবীকে প্রদক্ষিণ</Chip>
        </div>
      </div>

      <div style={{ position: "absolute", left: 140, top: 390, width: 1300 }}>
        <Entrance delay={s0} y={60} from={1.12} preset="bouncy">
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 158, lineHeight: 1.3, letterSpacing: 0 }}>
            <span style={gradientText}>এত দ্রুতগতিতে</span>
          </div>
        </Entrance>
        <WordReveal text="চলা Satellite" size={104} delay={s0 + 10} per={5} />
      </div>

      <div style={{ position: "absolute", left: sx, top: sy, width: 190, height: 190, opacity: satVis }}>
        {[3, 2, 1].map((k) => (
          <div key={k} style={{ position: "absolute", inset: 0, transform: `translateX(${k * 46}px)`, opacity: 0.12 * (4 - k), filter: "blur(3px)" }}>
            <KenImg src="assets/satellite.png" zoom={1.02} />
          </div>
        ))}
        <KenImg src="assets/satellite.png" zoom={1.02} />
      </div>

      <div style={{ position: "absolute", left: 1530, top: 470 }}>
        <Phone height={560} delay={L(T.speed.device) - 6} />
      </div>
    </SceneShell>
  );
};
