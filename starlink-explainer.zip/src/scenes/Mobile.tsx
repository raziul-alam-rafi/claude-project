import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { Breathe, Entrance, KenImg, WordReveal, clampX, gradientText } from "../components/Motion";
import { Chip } from "../components/Glass";
import { SceneShell } from "../components/Shell";
import { Phone } from "./Link";
import { theme } from "../theme";
import { T, loc } from "../timing";

const PH = { x: 1400, y: 560 }, SAT = { x: 1705, y: 190 };

export const Mobile: React.FC = () => {
  const frame = useCurrentFrame();
  const L = (g: number) => loc("mobile", g);
  const strike = interpolate(frame, [L(T.mobile.noAnt), L(T.mobile.noAnt) + 12], [0, 1], { easing: theme.ease.out, ...clampX });
  const beamIn = interpolate(frame, [L(T.mobile.direct), L(T.mobile.direct) + 14], [0, 1], { easing: theme.ease.out, ...clampX });
  const rings = [0, 1, 2].map((i) => {
    const k = frame - L(T.mobile.mob) - 6 - i * 14;
    const t = k < 0 ? 0 : (k % 42) / 42;
    return { r: 40 + t * 150, o: k < 0 ? 0 : (1 - t) * 0.7 * beamIn };
  });
  return (
    <SceneShell seed={7} last>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <line x1={SAT.x - 40} y1={SAT.y + 70} x2={SAT.x + (PH.x - SAT.x) * beamIn} y2={SAT.y + 70 + (PH.y - 200 - SAT.y) * beamIn} stroke={theme.colors.accent}
          strokeWidth={6} strokeLinecap="round" strokeDasharray="2 18" strokeDashoffset={-frame * 1.4} />
        {rings.map((r, i) => (
          <circle key={i} cx={PH.x} cy={PH.y - 200} r={r.r} fill="none" stroke={theme.colors.accent} strokeWidth={4} opacity={r.o} />
        ))}
      </svg>

      <div style={{ position: "absolute", left: SAT.x - 100, top: SAT.y - 100, width: 200, height: 200 }}>
        <Entrance delay={L(T.mobile.direct) - 6} y={-60} from={0.5} preset="bouncy">
          <Breathe amp={7} speed={26}><KenImg src="assets/satellite.png" zoom={1.06} /></Breathe>
        </Entrance>
      </div>

      <div style={{ position: "absolute", left: PH.x - 167, top: 200 }}>
        <Phone height={740} delay={L(T.mobile.mob)} arcDelay={L(T.mobile.direct) + 14} />
      </div>

      <div style={{ position: "absolute", left: 120, top: 230, width: 1000 }}>
        <Entrance delay={L(T.mobile.noAnt)} y={30}>
          <div style={{ position: "relative", display: "inline-block" }}>
            <Chip size={72} style={{ opacity: 0.95 }}>Antenna ছাড়া</Chip>
            <div style={{ position: "absolute", left: 28, top: "52%", height: 7, width: `calc((100% - 56px) * ${strike})`, background: theme.colors.text, borderRadius: 7 }} />
          </div>
        </Entrance>
        <WordReveal text="সরাসরি Mobile এ" size={110} delay={L(T.mobile.direct)} per={5} style={{ marginTop: 34 }} />
        <Entrance delay={L(T.mobile.star)} y={60} from={1.15} preset="bouncy">
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: 176, lineHeight: 1.25, letterSpacing: 0, filter: `drop-shadow(0 0 40px ${theme.colors.glow})` }}>
            <span style={gradientText}>Starlink</span>
          </div>
        </Entrance>
      </div>
    </SceneShell>
  );
};
