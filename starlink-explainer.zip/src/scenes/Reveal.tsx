import React from "react";
import { Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { Breathe, Entrance, KenImg, WordReveal, clampX } from "../components/Motion";
import { Chip, Glass } from "../components/Glass";
import { SceneShell } from "../components/Shell";
import { theme } from "../theme";
import { T, loc } from "../timing";

export const Reveal: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const L = (g: number) => loc("reveal", g);
  const a = L(T.reveal.ans);
  const shrink = spring({ frame: frame - (a - 4), fps, config: theme.spring.smooth });
  const dishP = interpolate(frame, [a + 2, a + 26], [0, 1], { easing: theme.ease.out, ...clampX });
  const scale = interpolate(shrink, [0, 1], [1, 0.56]);
  const cardY = interpolate(shrink, [0, 1], [0, -352]);
  const glowP = spring({ frame: frame - (a + 6), fps, config: theme.spring.smooth });
  return (
    <SceneShell seed={5}>
      <div style={{ position: "absolute", left: 360, top: 300, width: 1200, height: 440, transform: `translateY(${cardY}px) scale(${scale})`, transformOrigin: "50% 50%" }}>
        <Entrance delay={L(T.reveal.q)} y={50} from={0.9}>
          <Glass style={{ width: 1200, height: 440, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 18 }}>
            <Entrance delay={L(T.reveal.dev)} y={16}><Chip size={44}>আপনার Device</Chip></Entrance>
            <WordReveal text="সংযোগ ধরে রাখে কিভাবে?" size={108} delay={L(T.reveal.q) + 6} per={5} hl={["কিভাবে?"]} justify="center" />
          </Glass>
        </Entrance>
      </div>

      <div style={{ position: "absolute", left: 340, top: 410, width: 1240, height: 460, opacity: dishP,
        clipPath: `inset(0 ${(1 - dishP) * 100}% 0 0 round 36px)`, transform: `translateY(${(1 - dishP) * 40}px) scale(${interpolate(dishP, [0, 1], [0.94, 1])})` }}>
        <div style={{ position: "absolute", inset: -60, borderRadius: 120, opacity: glowP * 0.9,
          background: `radial-gradient(ellipse at 50% 60%, ${theme.colors.primary}55, transparent 68%)`, filter: "blur(20px)" }} />
        <Glass style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Breathe amp={5} speed={36}>
            <div style={{ width: 1100, height: 407, borderRadius: 26, overflow: "hidden", background: theme.colors.text }}>
              <KenImg src="assets/dish_photo.jpg" zoom={1.06} style={{ objectFit: "cover", mixBlendMode: "multiply" }} />
            </div>
          </Breathe>
        </Glass>
      </div>

      <div style={{ position: "absolute", left: 260, top: 905, width: 1400 }}>
        <WordReveal text="ছোট্ট একটা Dish এর ভিতরে" size={72} delay={a + 12} per={4} hl={["Dish"]} justify="center" />
      </div>
    </SceneShell>
  );
};
