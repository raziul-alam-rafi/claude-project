import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Breathe, BnCounter, Entrance, KenImg, WordReveal, clampX } from "../components/Motion";
import { DotGlobe } from "../components/Globe";
import { Chip, Glass } from "../components/Glass";
import { SceneShell } from "../components/Shell";
import { theme } from "../theme";
import { T, loc, FPS } from "../timing";

const CX = 520, CY = 585, GLOBE = 500, R1 = 395, R2 = 455;

export const Orbit: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const L = (g: number) => loc("orbit", g);
  const start = L(T.orbit.head);
  const ang = (frame / 150) * Math.PI * 2 - Math.PI / 2;
  const dots = Array.from({ length: 16 }).map((_, i) => {
    const ring = i % 2 === 0 ? R1 : R2;
    const a = ang * (i % 2 === 0 ? 1 : -0.7) + (i / 16) * Math.PI * 2 * 1.3;
    const p = spring({ frame: frame - start - 10 - i * 3, fps, config: theme.spring.snappy });
    return { x: CX + Math.cos(a) * ring, y: CY + Math.sin(a) * ring, p, i };
  });
  const sat = { x: CX + Math.cos(ang) * R1, y: CY + Math.sin(ang) * R1 };
  const dimA = (-38 * Math.PI) / 180;
  const dimP = spring({ frame: frame - L(T.orbit.km) + 6, fps, config: theme.spring.smooth });
  const d1 = { x: CX + Math.cos(dimA) * (GLOBE / 2 + 4), y: CY + Math.sin(dimA) * (GLOBE / 2 + 4) };
  const d2 = { x: CX + Math.cos(dimA) * R1, y: CY + Math.sin(dimA) * R1 };
  const dm = { x: d1.x + (d2.x - d1.x) * dimP, y: d1.y + (d2.y - d1.y) * dimP };
  const ringP = interpolate(frame, [L(T.orbit.min), L(T.orbit.min) + 40], [0, 1], { easing: theme.ease.inOut, ...clampX });
  const C = 2 * Math.PI * 62;
  return (
    <SceneShell seed={3}>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <circle cx={CX} cy={CY} r={R1} fill="none" stroke={theme.colors.line} strokeWidth={2.5} strokeDasharray="4 14" opacity={interpolate(frame, [start, start + 14], [0, 1], clampX)} />
        <circle cx={CX} cy={CY} r={R2} fill="none" stroke={theme.colors.line} strokeWidth={2} strokeDasharray="4 14" opacity={0.6 * interpolate(frame, [start + 8, start + 22], [0, 1], clampX)} />
        {dots.map((d) => (
          <circle key={d.i} cx={d.x} cy={d.y} r={9 * d.p} fill={theme.colors.accent} opacity={0.9 * Math.min(1, d.p)} />
        ))}
        <line x1={d1.x} y1={d1.y} x2={dm.x} y2={dm.y} stroke={theme.colors.text} strokeWidth={4} strokeLinecap="round" />
        <circle cx={d1.x} cy={d1.y} r={8 * dimP} fill={theme.colors.text} />
        <circle cx={dm.x} cy={dm.y} r={8 * dimP} fill={theme.colors.text} />
      </svg>

      <div style={{ position: "absolute", left: CX - GLOBE / 2, top: CY - GLOBE / 2 }}>
        <Entrance delay={start - 2} y={0} from={0.85}><DotGlobe size={GLOBE} speed={0.014} /></Entrance>
      </div>

      <div style={{ position: "absolute", left: sat.x - 80, top: sat.y - 80, width: 160, height: 160, transform: `rotate(${(ang * 180) / Math.PI + 90}deg)` }}>
        <Entrance delay={start + 6} y={0} from={0.4} preset="bouncy"><KenImg src="assets/satellite.png" zoom={1.05} /></Entrance>
      </div>

      <div style={{ position: "absolute", left: d2.x + 30, top: d2.y - 96 }}>
        <Entrance delay={L(T.orbit.km) + 10} y={16}><Chip size={34}>৫৫০ কিমি</Chip></Entrance>
      </div>

      <div style={{ position: "absolute", left: 1080, top: 120, width: 780 }}>
        <WordReveal text="হাজার হাজার Satellite" size={74} delay={start} hl={["Satellite"]} />
      </div>

      <div style={{ position: "absolute", left: 1080, top: 330 }}>
        <Entrance delay={L(T.orbit.km)} y={50} x={60} preset="smooth">
          <Breathe amp={4}>
            <Glass style={{ width: 760, height: 250, padding: "0 56px", display: "flex", alignItems: "center", gap: 36 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
                <BnCounter to={550} delay={L(T.orbit.km)} size={150} style={{ color: theme.colors.text, minWidth: 270 }} />
                <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.strong, fontSize: 54, color: theme.colors.textDim }}>কিলোমিটার</span>
              </div>
            </Glass>
          </Breathe>
        </Entrance>
      </div>

      <div style={{ position: "absolute", left: 1080, top: 640 }}>
        <Entrance delay={L(T.orbit.min)} y={50} x={60} preset="smooth">
          <Breathe amp={4} phase={2}>
            <Glass style={{ width: 760, height: 250, padding: "0 56px", display: "flex", alignItems: "center", gap: 40 }}>
              <svg width={150} height={150} viewBox="0 0 150 150">
                <circle cx={75} cy={75} r={62} fill="none" stroke={theme.colors.line} strokeWidth={9} opacity={0.5} />
                <circle cx={75} cy={75} r={62} fill="none" stroke={theme.colors.accent} strokeWidth={9} strokeLinecap="round"
                  strokeDasharray={C} strokeDashoffset={C * (1 - ringP)} transform="rotate(-90 75 75)" />
                <circle cx={75 + Math.cos(ringP * Math.PI * 2 - Math.PI / 2) * 62} cy={75 + Math.sin(ringP * Math.PI * 2 - Math.PI / 2) * 62} r={9} fill={theme.colors.text} />
              </svg>
              <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
                <BnCounter to={95} delay={L(T.orbit.min)} size={150} style={{ color: theme.colors.text, minWidth: 170 }} />
                <span style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.strong, fontSize: 54, color: theme.colors.textDim }}>মিনিট</span>
              </div>
            </Glass>
          </Breathe>
        </Entrance>
      </div>
    </SceneShell>
  );
};
