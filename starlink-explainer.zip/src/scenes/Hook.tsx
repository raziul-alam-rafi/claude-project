import React from "react";
import { Img, staticFile } from "remotion";
import { Breathe, Entrance, Link, WordReveal, gradientText } from "../components/Motion";
import { DotGlobe } from "../components/Globe";
import { Chip, LogoTile } from "../components/Glass";
import { SceneShell } from "../components/Shell";
import { theme } from "../theme";
import { T, loc } from "../timing";

const CX = 1400, CY = 540, G = 600;
const YT = { x: 1190, y: 205 }, FB = { x: 1655, y: 870 }, TILE = 190;

export const Hook: React.FC = () => {
  const L = (g: number) => loc("hook", g);
  return (
    <SceneShell seed={1} first>
      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <Link x1={YT.x} y1={YT.y} x2={CX} y2={CY} delay={L(T.hook.yt) + 6} packets={2} />
        <Link x1={FB.x} y1={FB.y} x2={CX} y2={CY} delay={L(T.hook.fb) + 6} packets={2} />
      </svg>

      <div style={{ position: "absolute", left: CX - G / 2, top: CY - G / 2 }}>
        <Entrance delay={L(T.hook.title) + 4} y={0} from={0.82} preset="smooth">
          <Breathe amp={5} speed={34}><DotGlobe size={G} /></Breathe>
        </Entrance>
      </div>

      <div style={{ position: "absolute", left: YT.x - TILE / 2, top: YT.y - TILE / 2 }}>
        <Entrance delay={L(T.hook.yt)} y={30} from={0.6} preset="bouncy"><Breathe amp={5} phase={1}><LogoTile logo="youtube" size={TILE} /></Breathe></Entrance>
      </div>
      <div style={{ position: "absolute", left: YT.x + TILE / 2 + 18, top: YT.y - 26 }}>
        <Entrance delay={L(T.hook.yt) + 6} y={0} x={-20}><Chip>Server</Chip></Entrance>
      </div>
      <div style={{ position: "absolute", left: FB.x - TILE / 2, top: FB.y - TILE / 2 }}>
        <Entrance delay={L(T.hook.fb)} y={30} from={0.6} preset="bouncy"><Breathe amp={5} phase={2}><LogoTile logo="facebook" size={TILE} /></Breathe></Entrance>
      </div>
      <div style={{ position: "absolute", left: FB.x - TILE / 2 - 150, top: FB.y - 26 }}>
        <Entrance delay={L(T.hook.fb) + 6} y={0} x={20}><Chip>Server</Chip></Entrance>
      </div>

      <div style={{ position: "absolute", left: 120, top: 250, width: 960 }}>
        <Entrance delay={L(T.hook.title)} y={70} from={1.18} preset="bouncy">
          <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.display, fontSize: theme.size.hero, lineHeight: 1.25, letterSpacing: 0,
            filter: `drop-shadow(0 0 40px ${theme.colors.glow})` }}>
            <span style={gradientText}>Starlink</span>
          </div>
        </Entrance>
        <WordReveal text="পৃথিবীর Internet Network" size={80} delay={L(T.hook.title) + 14} per={4} style={{ marginTop: 14 }} />
      </div>
    </SceneShell>
  );
};
