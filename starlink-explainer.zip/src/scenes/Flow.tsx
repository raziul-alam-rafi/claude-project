import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { Breathe, Entrance, KenImg, Link, WordReveal, clampX } from "../components/Motion";
import { Chip, Glass } from "../components/Glass";
import { SceneShell } from "../components/Shell";
import { theme } from "../theme";
import { T, loc } from "../timing";

const CY = 520, W = 380, H = 380;
const XS = [290, 960, 1630];

const House: React.FC<{ delay: number }> = ({ delay }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay - 8, fps, config: theme.spring.snappy });
  return (
    <svg width={230} height={264} viewBox="0 -34 200 230">
      <path d="M30 98 L100 36 L170 98" fill="none" stroke={theme.colors.text} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />
      <path d="M48 90 V158 H152 V90" fill={theme.colors.surfaceStrong} stroke={theme.colors.text} strokeWidth={9} strokeLinejoin="round" />
      <rect x={88} y={116} width={24} height={42} rx={5} fill={theme.colors.accent} />
      {[26, 40, 54].map((r, i) => (
        <path key={r} d={`M ${100 - r} ${24 - r * 0.2} A ${r} ${r} 0 0 1 ${100 + r} ${24 - r * 0.2}`} fill="none" stroke={theme.colors.accent} strokeWidth={6}
          strokeLinecap="round" opacity={Math.min(1, p) * (0.5 + 0.5 * Math.sin(frame / 7 - i))} transform="translate(0 -4)" />
      ))}
    </svg>
  );
};

export const Flow: React.FC = () => {
  const frame = useCurrentFrame();
  const L = (g: number) => loc("flow", g);
  const netP = interpolate(frame, [L(T.flow.net), L(T.flow.net) + 14], [0, 1], { easing: theme.ease.out, ...clampX });
  const Node: React.FC<{ x: number; delay: number; label: string; children: React.ReactNode }> = ({ x, delay, label, children }) => (
    <div style={{ position: "absolute", left: x - W / 2, top: CY - H / 2 }}>
      <Entrance delay={delay} y={50} from={0.9} preset="bouncy">
        <Breathe amp={4} phase={x / 300}>
          <Glass style={{ width: W, height: H, display: "flex", alignItems: "center", justifyContent: "center" }}>{children}</Glass>
        </Breathe>
      </Entrance>
      <div style={{ position: "absolute", top: H + 28, left: 0, width: W, display: "flex", justifyContent: "center" }}>
        <Entrance delay={delay + 8} y={16}><Chip size={42}>{label}</Chip></Entrance>
      </div>
    </div>
  );
  return (
    <SceneShell seed={6}>
      <div style={{ position: "absolute", left: 160, top: 70, width: 1600 }}>
        <WordReveal text="সাধারণ বাসাবাড়িতে ছোট্ট Dish Antenna" size={72} delay={L(T.flow.house) - 4} per={4} hl={["Dish", "Antenna"]} justify="center" />
      </div>

      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <Link x1={XS[0] + W / 2 + 12} y1={CY} x2={XS[1] - W / 2 - 12} y2={CY} delay={L(T.flow.star) + 16} packets={0} />
        <Link x1={XS[1] + W / 2 + 12} y1={CY} x2={XS[2] - W / 2 - 12} y2={CY} delay={L(T.flow.net) + 2} packets={2} />
      </svg>

      <Node x={XS[2]} delay={L(T.flow.house)} label="বাসাবাড়ি"><House delay={L(T.flow.house)} /></Node>
      <Node x={XS[1]} delay={L(T.flow.dish)} label="Dish Antenna">
        <div style={{ width: 330, height: 122, borderRadius: 22, overflow: "hidden", background: theme.colors.text }}>
          <KenImg src="assets/dish_photo.jpg" zoom={1.08} style={{ objectFit: "cover", mixBlendMode: "multiply" }} />
        </div>
      </Node>
      <Node x={XS[0]} delay={L(T.flow.star)} label="Starlink Satellite">
        <div style={{ width: 240, height: 240 }}><KenImg src="assets/satellite.png" zoom={1.06} /></div>
      </Node>

      <div style={{ position: "absolute", left: XS[1] + W / 2 - 20, top: CY - 118, width: XS[2] - XS[1] - W + 40, display: "flex", justifyContent: "center",
        opacity: netP, transform: `translateY(${(1 - netP) * 20}px)` }}>
        <Chip size={38}>Internet সেবা</Chip>
      </div>
    </SceneShell>
  );
};
