import React from "react";
import { Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { Breathe, Entrance, KenImg, Link, WordReveal, clampX } from "../components/Motion";
import { Chip, Glass, LogoTile } from "../components/Glass";
import { SceneShell } from "../components/Shell";
import { theme } from "../theme";
import { T, loc } from "../timing";

export const PhoneScreenArcs: React.FC<{ delay: number; size: number }> = ({ delay, size }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      {[44, 30, 16].map((r, i) => {
        const p = spring({ frame: frame - delay - i * 5, fps, config: theme.spring.snappy });
        return <path key={r} d={`M ${50 - r} ${74 - r * 0.2} A ${r} ${r} 0 0 1 ${50 + r} ${74 - r * 0.2}`} fill="none" stroke={theme.colors.accent}
          strokeWidth={6} strokeLinecap="round" opacity={p * (0.55 + 0.45 * Math.sin(frame / 8 - i))} />;
      })}
      <circle cx={50} cy={78} r={5.5} fill={theme.colors.text} opacity={interpolate(frame - delay, [0, 8], [0, 1], clampX)} />
    </svg>
  );
};

export const Phone: React.FC<{ height: number; delay: number; arcDelay?: number; children?: React.ReactNode }> = ({ height, delay, arcDelay, children }) => {
  const w = Math.round((height * 667) / 1400);
  return (
    <Entrance delay={delay} y={60} from={0.9}>
      <div style={{ position: "relative", width: w, height, filter: `drop-shadow(0 40px 60px ${theme.colors.shade})` }}>
        <KenImg src="assets/phone.png" zoom={1.03} />
        <div style={{ position: "absolute", left: "6%", right: "6%", top: "3.4%", bottom: "6.4%", borderRadius: "6%", overflow: "hidden",
          display: "flex", alignItems: "center", justifyContent: "center",
          background: `radial-gradient(circle at 50% 70%, ${theme.colors.primary}55, ${theme.colors.ink} 70%)` }}>
          {arcDelay !== undefined ? <PhoneScreenArcs delay={arcDelay} size={Math.round(w * 0.62)} /> : null}
          {children}
        </div>
      </div>
    </Entrance>
  );
};

export const LinkScene: React.FC = () => {
  const frame = useCurrentFrame();
  const L = (g: number) => loc("link", g);
  const sx = 335, sy = 540;                 // server card center
  const px = 1400, py = 560;                // phone left anchor
  const satX = 960, satY = 400;
  const bAmt = interpolate(frame, [L(T.link.sat), L(T.link.sat) + 14], [0, 1], { easing: theme.ease.out, ...clampX });
  return (
    <SceneShell seed={2}>
      <div style={{ position: "absolute", left: 600, top: 100, width: 760 }}>
        <WordReveal text="আপনাকে যুক্ত করা" size={80} delay={L(T.link.you)} hl={["যুক্ত"]} justify="center" />
      </div>

      <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
        <Link x1={sx + 205} y1={sy + 20} x2={px} y2={py} delay={L(T.link.join)} packets={2} fade={1 - bAmt} />
        <Link x1={sx + 205} y1={sy + 20} x2={satX} y2={satY + 40} delay={L(T.link.sat) + 4} packets={2} fade={bAmt} />
        <Link x1={satX} y1={satY + 40} x2={px} y2={py} delay={L(T.link.sat) + 12} packets={2} fade={bAmt} />
      </svg>

      <div style={{ position: "absolute", left: sx - 205, top: sy - 165 }}>
        <Entrance delay={L(T.link.server)} y={40} x={-60}>
          <Breathe amp={4}>
            <Glass style={{ width: 410, height: 330, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 30 }}>
              <div style={{ display: "flex", gap: 26 }}>
                <LogoTile logo="youtube" size={150} />
                <LogoTile logo="facebook" size={150} />
              </div>
              <Chip>Server</Chip>
            </Glass>
          </Breathe>
        </Entrance>
      </div>

      <div style={{ position: "absolute", left: satX - 105, top: satY - 105, width: 210, height: 210 }}>
        <Entrance delay={L(T.link.sat)} y={-50} from={0.5} preset="bouncy">
          <Breathe amp={7} speed={26}><KenImg src="assets/satellite.png" zoom={1.06} /></Breathe>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: satX - 150, top: 690, width: 300, display: "flex", justifyContent: "center" }}>
        <Entrance delay={L(T.link.low)} y={20}><Chip size={42}>নিচু কক্ষপথ</Chip></Entrance>
      </div>

      <div style={{ position: "absolute", left: 1400, top: 140 }}>
        <Phone height={800} delay={L(T.link.you)} arcDelay={L(T.link.join) + 10} />
      </div>
    </SceneShell>
  );
};
