// SFX timeline: every sound is tied to the same SRT-derived frames the visuals use.
import { SC, SCENE_ORDER, T, PRE } from "./timing";

export type SfxName = "pop" | "click" | "whoosh" | "swipe" | "chime" | "thud";
export type SfxEvent = { frame: number; name: SfxName; volume: number; rate?: number };

const base: Record<SfxName, number> = { pop: 0.30, click: 0.30, whoosh: 0.26, swipe: 0.24, chime: 0.26, thud: 0.22 };
const ev = (frame: number, name: SfxName, rate = 1, gain = 1): SfxEvent => ({ frame: Math.max(0, frame), name, volume: +(base[name] * gain).toFixed(3), rate });

export const sfxEvents: SfxEvent[] = [
  // hook
  ev(T.hook.title - 2, "thud"),
  ev(T.hook.title + 10, "whoosh", 1, 0.9),
  ev(T.hook.yt, "chime", 1.0),
  ev(T.hook.fb, "chime", 1.12, 0.92),
  // link
  ev(T.link.you, "pop", 1.0),
  ev(T.link.join + 4, "click"),
  ev(T.link.sat, "chime", 0.94, 0.9),
  // orbit
  ev(T.orbit.head, "pop", 1.04),
  ev(T.orbit.km, "pop", 0.96),
  ev(T.orbit.min, "pop", 1.06),
  // speed
  ev(T.speed.fast, "whoosh", 1.1),
  ev(T.speed.device, "click", 0.95),
  // reveal
  ev(T.reveal.q, "whoosh", 0.95, 0.85),
  ev(T.reveal.dish, "chime", 1.06),
  // flow
  ev(T.flow.house, "pop", 1.05),
  ev(T.flow.dish, "pop", 0.98),
  ev(T.flow.star, "pop", 0.92),
  ev(T.flow.net, "click"),
  // mobile
  ev(T.mobile.noAnt, "click", 1.05),
  ev(T.mobile.mob, "pop", 1.0),
  ev(T.mobile.star, "whoosh", 1.05, 0.8),
  // scene transitions (swipe lands with the wipe)
  ...SCENE_ORDER.slice(1).map((k, i) => ev(SC[k].from - PRE - 2, "swipe", 1 + (i % 3) * 0.04)),
].sort((a, b) => a.frame - b.frame);
